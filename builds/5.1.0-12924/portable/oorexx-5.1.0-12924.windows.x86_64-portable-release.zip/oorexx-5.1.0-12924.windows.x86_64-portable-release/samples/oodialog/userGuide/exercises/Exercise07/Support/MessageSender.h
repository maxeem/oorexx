#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define DLG_MESSAGESENDER                       103
#define IDC_MS_ERRORMSG                         1000
#define IDC_MS_CLEAR                            1002
#define IDC_MS_DATA                             1010
#define IDC_MS_REPLY                            1011
#define IDC_MS_SEND                             1012
#define IDC_MS_COMPONENT                        1015
#define IDC_MS_METHOD                           1016
#define IDC_MS_STORETARGET                      1018
#define IDC_MS_STOREMETHOD                      1020
