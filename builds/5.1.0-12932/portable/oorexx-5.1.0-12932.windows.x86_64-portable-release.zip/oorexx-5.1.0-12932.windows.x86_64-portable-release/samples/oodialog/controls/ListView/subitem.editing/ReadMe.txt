/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Copyright (c) 2013-2014 Rexx Language Association. All rights reserved.    */
/*                                                                            */
/* This program and the accompanying materials are made available under       */
/* the terms of the Common Public License v1.0 which accompanies this         */
/* distribution. A copy is also available at the following address:           */
/* https://www.oorexx.org/license.html                                        */
/*                                                                            */
/* Redistribution and use in source and binary forms, with or                 */
/* without modification, are permitted provided that the following            */
/* conditions are met:                                                        */
/*                                                                            */
/* Redistributions of source code must retain the above copyright             */
/* notice, this list of conditions and the following disclaimer.              */
/* Redistributions in binary form must reproduce the above copyright          */
/* notice, this list of conditions and the following disclaimer in            */
/* the documentation and/or other materials provided with the distribution.   */
/*                                                                            */
/* Neither the name of Rexx Language Association nor the names                */
/* of its contributors may be used to endorse or promote products             */
/* derived from this software without specific prior written permission.      */
/*                                                                            */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        */
/* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          */
/* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS          */
/* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   */
/* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED   */
/* TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,        */
/* OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY     */
/* OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING    */
/* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS         */
/* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.               */
/*                                                                            */
/*----------------------------------------------------------------------------*/

  	ReadMe

  1.  ooDialog - List-view Example Programs
  -----------------------------------------------

  This directory contains several, similar, example programs that
  demonstrate how to embedd a dialog control within the the list-view.
  The embedded controls allow the user to do in-place editing of the
  subitems in the list-view when in report mode.

  For these first 3 examples, to activate subitem editing, the user first
  selects a row by clicking on it with the mouse.  If the user then clicks
  one more time, the embedded control becomes active.  The user enters the
  value desired.  At that point, hitting enter makes the change.  If the
  user hits the escape key, or clicks somewhere else on the list-view, the
  change is abandoned.

    - dropDownComboBox.rex

    Embeds a drop down combo box in the list-view.

    - dropDownListComboBox.rex

    Embeds a drop down list combo box in the list-view.

    - editControl.rex

    Embeds an edit control in the list-view.

  The importList.rex example use a slightly different UI.  The first
  column of the list view has an embedded combo box.  To activate the
  control the user single clicks on the first column of an item.  The
  third column has an embedded edit control.  To activate the edit
  control, the user double clicks on the third column of an item.  For
  both controls if the user clicks anywhere else in the application, or
  hits the enter or tab key, the current text in the control is saved.
  The Esc key cancels any change.  The example also shows how to use the
  ResizingAdmin class and the BrowseForFolder class.

    - importList.rex
